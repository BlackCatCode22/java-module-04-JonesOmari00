//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Animal lion = new Animal("A001", "2020-05-10", "Golden", "Africa", 190,
                "Leo", "Roar", "2021-01-15", "Male", 3);

        System.out.println("Animal Name: " + lion.getName());
        System.out.println("Sound: " + lion.getAnimalSound());
    }
}
