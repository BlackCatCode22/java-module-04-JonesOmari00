 public class Animal {
    // Private attributes
    private String animalID;
    private String birthdate;
    private String color;
    private String origin;
    private int weight;
    private String name;
    private String animalSound;
    private String arrivalDate;
    private String sex;
    private int numOfAnimal;

    // Empty constructor
    public Animal() {}

    // Parameterized constructor
    public Animal(String animalID, String birthdate, String color, String origin, int weight,
                  String name, String animalSound, String arrivalDate, String sex, int numOfAnimal) {
        this.animalID = animalID;
        this.birthdate = birthdate;
        this.color = color;
        this.origin = origin;
        this.weight = weight;
        this.name = name;
        this.animalSound = animalSound;
        this.arrivalDate = arrivalDate;
        this.sex = sex;
        this.numOfAnimal = numOfAnimal;
    }

    // Getters and Setters
    public String getAnimalID() {
        return animalID;
    }

    public void setAnimalID(String animalID) {
        this.animalID = animalID;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnimalSound() {
        return animalSound;
    }

    public void setAnimalSound(String animalSound) {
        this.animalSound = animalSound;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getNumOfAnimal() {
        return numOfAnimal;
    }

    public void setNumOfAnimal(int numOfAnimal) {
        this.numOfAnimal = numOfAnimal;
    }
}

